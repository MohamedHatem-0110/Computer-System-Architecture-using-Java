
public class PC{
	int pc;
	public PC() {
		pc = 0;
	}
	public int getPc() {
		return pc;
	}
	public void setPc(int pc) {
		this.pc = pc;
	}

}
